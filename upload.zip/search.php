<section>
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-md-8">
            
            <div class="title">
            <center> <img src="images/logo.jpeg" /></center>
              <p class="text-center font-weight-bold">Search Project</p>
            </div>
            <hr class="my-1" />

            <div class="body text-center">
              <input type="text" id="search" name="search" class="form-control" />
              <div>
                <button class="btn btn-primary">Search</button>
              </div>
            </div>


            </div>
          </div>
        </div>
    </section>


<section>
<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-6" id="showresult" style="height:400px; overflow:auto">
    
    
    </div>
  </div>
</div>
</section>



<section>
<script>



</script>
</section>
 